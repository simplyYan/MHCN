<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// ========== BACKEND PHP ==========

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    ob_start();
    header('Content-Type: application/json; charset=utf-8');

    function sendJsonResponse($data) {
        ob_clean();
        echo json_encode($data);
        exit;
    }

    $action = $_POST['action'] ?? '';
    $roomname = $_POST['roomname'] ?? '';
    $key = $_POST['key'] ?? '';
    $chatsDir = __DIR__ . '/chats';
    if (!is_dir($chatsDir)) mkdir($chatsDir, 0777, true);

    // Helper: safe room name
    function safe_roomname($name) {
        return preg_match('/^[a-zA-Z0-9_-]+$/', $name) ? $name : false;
    }

    // Helper: encryption
    function encrypt_json_php($json, $key) {
        $iv = random_bytes(12);
        $key_bin = hash_pbkdf2('sha256', $key, 'mhcn_salt', 100000, 32, true);
        $cipher = openssl_encrypt(json_encode($json), 'aes-256-gcm', $key_bin, OPENSSL_RAW_DATA, $iv, $tag);
        return base64_encode($iv) . ':' . base64_encode($cipher . $tag);
    }
    function decrypt_json_php($cipher, $key) {
        $parts = explode(':', $cipher);
        if (count($parts) !== 2) return null;
        $iv = base64_decode($parts[0]);
        $data = base64_decode($parts[1]);
        $ciphertext = substr($data, 0, -16);
        $tag = substr($data, -16);
        $key_bin = hash_pbkdf2('sha256', $key, 'mhcn_salt', 100000, 32, true);
        $json = openssl_decrypt($ciphertext, 'aes-256-gcm', $key_bin, OPENSSL_RAW_DATA, $iv, $tag);
        return $json ? json_decode($json, true) : null;
    }

    // ========== CREATE CHATROOM ==========
    if ($action === 'create_room') {
        if (!($room = safe_roomname($roomname))) {
            sendJsonResponse(['success'=>false, 'error'=>'Invalid chatroom name.']);
        }
        $file = "$chatsDir/$room.json";
        if (file_exists($file)) {
            sendJsonResponse(['success'=>false, 'error'=>'Chatroom already exists.']);
        }
        $init = [];
        $cipher = encrypt_json_php($init, $key);
        file_put_contents($file, $cipher);
        sendJsonResponse(['success'=>true]);
    }

    // ========== GET CHATROOM ==========
    if ($action === 'get_room') {
        if (!($room = safe_roomname($roomname))) {
            sendJsonResponse(['success'=>false, 'error'=>'Invalid chatroom name.']);
        }
        $file = "$chatsDir/$room.json";
        if (!file_exists($file)) {
            sendJsonResponse(['success'=>false, 'error'=>'Chatroom not found.']);
        }
        $cipher = file_get_contents($file);
        sendJsonResponse(['success'=>true, 'cipher'=>$cipher]);
    }

    // ========== SEND MESSAGE ==========
    if ($action === 'send_message') {
        $message = json_decode($_POST['message'] ?? '', true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            sendJsonResponse(['success'=>false, 'error'=>'Invalid message.']);
        }
        if (!($room = safe_roomname($roomname))) {
            sendJsonResponse(['success'=>false, 'error'=>'Invalid chatroom name.']);
        }
        $file = "$chatsDir/$room.json";
        if (!file_exists($file)) {
            sendJsonResponse(['success'=>false, 'error'=>'Chatroom not found.']);
        }
        $cipher = file_get_contents($file);
        $messages = decrypt_json_php($cipher, $key);
        if (!is_array($messages)) $messages = [];
        // Limit message size
        if (isset($message['type']) && $message['type'] === 'text') {
            $message['text'] = substr($message['text'], 0, 500);
        }
        if (isset($message['type']) && $message['type'] === 'svg') {
            // Limit SVG to 100kb
            if (strlen($message['svg']) > 100*1024) {
                sendJsonResponse(['success'=>false, 'error'=>'SVG file too large.']);
            }
        }
        $messages[] = $message;
        $newCipher = encrypt_json_php($messages, $key);
        file_put_contents('php://stderr', "DEBUG: Reached here\n", FILE_APPEND);
        file_put_contents($file, $newCipher);
        sendJsonResponse(['success'=>true]);
    }

    // ========== DEFAULT ==========
    sendJsonResponse(['success'=>false, 'error'=>'Invalid action.']);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>madhatchatnet</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap 5 CDN -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: #181a1b;
            color: #f1f1f1;
            min-height: 100vh;
        }
        .mhcn-card {
            background: #23272b;
            border-radius: 1rem;
            box-shadow: 0 2px 16px #000a;
        }
        .mhcn-btn {
            background: #6f42c1;
            color: #fff;
            border: none;
        }
        .mhcn-btn:hover {
            background: #5936a8;
        }
        .chatroom-list-item {
            background: #23272b;
            border: 1px solid #343a40;
            border-radius: .5rem;
            margin-bottom: .5rem;
            padding: .75rem 1rem;
            cursor: pointer;
            transition: background .2s;
        }
        .chatroom-list-item:hover {
            background: #343a40;
        }
        .chat-messages {
            max-height: 60vh;
            overflow-y: auto;
            padding-bottom: 1rem;
        }
        .chat-message {
            margin-bottom: 1.2rem;
        }
        .chat-message .author {
            font-weight: bold;
            color: #b983ff;
        }
        .chat-message .timestamp {
            font-size: .85em;
            color: #aaa;
        }
        .chat-message .text {
            margin-top: .2rem;
            word-break: break-word;
        }
        .chat-message img {
            max-width: 200px;
            max-height: 200px;
            display: block;
            margin-top: .5rem;
            border-radius: .5rem;
            background: #fff;
        }
        .mhcn-scrollbar::-webkit-scrollbar {
            width: 8px;
            background: #23272b;
        }
        .mhcn-scrollbar::-webkit-scrollbar-thumb {
            background: #343a40;
            border-radius: 4px;
        }
        @media (max-width: 600px) {
            .mhcn-card {
                border-radius: 0;
                box-shadow: none;
            }
            .chat-messages {
                max-height: 40vh;
            }
        }
    </style>
</head>
<body>
<div class="container py-4">
    <div id="main-card" class="mhcn-card p-4 mx-auto" style="max-width: 480px;">
        <h2 class="text-center mb-4" style="font-family: monospace; letter-spacing: 2px;">madhatchatnet</h2>
        <div id="app-content"></div>
    </div>
</div>

<script>
// ========== CONFIG ==========
const API_URL = ""; // PHP is on the same page

// ========== UTILS ==========

// Generate SHA-256 hash (for password)
async function sha256(str) {
    const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(str));
    return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, '0')).join('');
}

// Generate encryption key from password
async function getKeyFromPassword(password) {
    const enc = new TextEncoder();
    const keyMaterial = await window.crypto.subtle.importKey(
        "raw", enc.encode(password), {name: "PBKDF2"}, false, ["deriveKey"]
    );
    return window.crypto.subtle.deriveKey(
        {
            name: "PBKDF2",
            salt: enc.encode("mhcn_salt"),
            iterations: 100000,
            hash: "SHA-256"
        },
        keyMaterial,
        {name: "AES-GCM", length: 256},
        false,
        ["encrypt", "decrypt"]
    );
}

// Encrypt JSON with key
async function encryptJSON(json, password) {
    const iv = window.crypto.getRandomValues(new Uint8Array(12));
    const key = await getKeyFromPassword(password);
    const enc = new TextEncoder();
    const data = enc.encode(JSON.stringify(json));
    const encrypted = await window.crypto.subtle.encrypt(
        {name: "AES-GCM", iv: iv},
        key,
        data
    );
    // Return base64(iv) + ":" + base64(cipher)
    return btoa(String.fromCharCode(...iv)) + ":" + btoa(String.fromCharCode(...new Uint8Array(encrypted)));
}

// Decrypt JSON with key
async function decryptJSON(cipher, password) {
    try {
        const [ivb64, cipherb64] = cipher.split(":");
        const iv = Uint8Array.from(atob(ivb64), c => c.charCodeAt(0));
        const data = Uint8Array.from(atob(cipherb64), c => c.charCodeAt(0));
        const key = await getKeyFromPassword(password);
        const decrypted = await window.crypto.subtle.decrypt(
            {name: "AES-GCM", iv: iv},
            key,
            data
        );
        const dec = new TextDecoder();
        return JSON.parse(dec.decode(decrypted));
    } catch (e) {
        return null;
    }
}

// ========== LOCAL STORAGE (account and saved chatrooms) ==========

function saveAccount(account) {
    localStorage.setItem("mhcn_account", JSON.stringify(account));
}
function getAccount() {
    return JSON.parse(localStorage.getItem("mhcn_account") || "null");
}
function saveChatrooms(chatrooms) {
    localStorage.setItem("mhcn_chatrooms", JSON.stringify(chatrooms));
}
function getChatrooms() {
    return JSON.parse(localStorage.getItem("mhcn_chatrooms") || "[]");
}
function addChatroomToLocal(name, key) {
    let rooms = getChatrooms();
    if (!rooms.find(r => r.name === name)) {
        rooms.push({name, key});
        saveChatrooms(rooms);
    }
}

// ========== UI RENDERING ==========

function show(content) {
    document.getElementById("app-content").innerHTML = content;
}

function showLogin() {
    show(`
        <form id="login-form" autocomplete="off">
            <div class="mb-3">
                <label class="form-label">Username</label>
                <input type="text" class="form-control" name="username" required maxlength="20">
            </div>
            <div class="mb-3">
                <label class="form-label">Password</label>
                <input type="password" class="form-control" name="password" required maxlength="32">
            </div>
            <div class="mb-3">
                <label class="form-label">Date of birth</label>
                <input type="date" class="form-control" name="dob" required>
            </div>
            <button type="submit" class="btn mhcn-btn w-100">Sign in / Create Account</button>
        </form>
    `);
    document.getElementById("login-form").onsubmit = async (e) => {
        e.preventDefault();
        const username = e.target.username.value.trim();
        const password = e.target.password.value;
        const dob = e.target.dob.value;
        if (!username || !password || !dob) return;
        const hash = await sha256(password);
        saveAccount({username, password: hash, dob});
        showHome();
    };
}

function showHome() {
    const account = getAccount();
    if (!account) return showLogin();
    const chatrooms = getChatrooms();
    let chatroomList = chatrooms.length ? chatrooms.map(r => `
        <div class="chatroom-list-item" data-name="${r.name}" data-key="${r.key}">
            <span class="me-2"><i class="bi bi-chat-dots"></i></span>
            <strong>${r.name}</strong>
        </div>
    `).join('') : `<div class="text-muted">No saved chatrooms.</div>`;
    show(`
        <div class="mb-4">
            <div class="d-flex align-items-center mb-2">
                <div class="me-auto">
                    <span class="fw-bold">Welcome, ${account.username}</span>
                </div>
                <button class="btn btn-sm btn-outline-light ms-2" id="logout-btn" title="Sign out"><i class="bi bi-box-arrow-right"></i></button>
            </div>
        </div>
        <div class="mb-4">
            <button class="btn mhcn-btn w-100 mb-2" id="create-room-btn">Create Chatroom</button>
            <button class="btn btn-outline-light w-100" id="join-room-btn">Join Chatroom</button>
        </div>
        <div class="mb-3">
            <div class="fw-bold mb-2">Saved chatrooms</div>
            <div id="chatroom-list">${chatroomList}</div>
        </div>
    `);
    document.getElementById("logout-btn").onclick = () => {
        localStorage.removeItem("mhcn_account");
        showLogin();
    };
    document.getElementById("create-room-btn").onclick = showCreateRoom;
    document.getElementById("join-room-btn").onclick = showJoinRoom;
    document.querySelectorAll(".chatroom-list-item").forEach(el => {
        el.onclick = () => {
            showEnterRoom(el.dataset.name, el.dataset.key);
        };
    });
}

function showCreateRoom() {
    show(`
        <form id="create-room-form" autocomplete="off">
            <div class="mb-3">
                <label class="form-label">Chatroom name</label>
                <input type="text" class="form-control" name="roomname" required maxlength="32" pattern="[a-zA-Z0-9_-]+" placeholder="Ex: room123">
                <div class="form-text">Only letters, numbers, _ and -</div>
            </div>
            <div class="mb-3">
                <label class="form-label">Encryption key</label>
                <input type="password" class="form-control" name="key" required maxlength="32" placeholder="Set a strong key">
            </div>
            <button type="submit" class="btn mhcn-btn w-100">Create</button>
            <button type="button" class="btn btn-link w-100 mt-2" id="back-btn">Back</button>
        </form>
    `);
    document.getElementById("back-btn").onclick = showHome;
    document.getElementById("create-room-form").onsubmit = async (e) => {
        e.preventDefault();
        const roomname = e.target.roomname.value.trim();
        const key = e.target.key.value;
        if (!roomname.match(/^[a-zA-Z0-9_-]+$/)) {
            alert("Invalid name.");
            return;
        }
        // Create chatroom on server
        const resp = await fetch(API_URL, {
            method: "POST",
            headers: {"Content-Type": "application/x-www-form-urlencoded"},
            body: new URLSearchParams({
                action: "create_room",
                roomname,
                key
            })
        });
        const text = await resp.text();
        console.log('Backend response:', text);
        let data;
        try {
            data = JSON.parse(text);
        } catch (e) {
            alert('Error processing server response: ' + text);
            return;
        }
        if (data.success) {
            addChatroomToLocal(roomname, key);
            showEnterRoom(roomname, key);
        } else {
            alert(data.error || "Error creating chatroom.");
        }
    };
}

function showJoinRoom() {
    show(`
        <form id="join-room-form" autocomplete="off">
            <div class="mb-3">
                <label class="form-label">Chatroom name</label>
                <input type="text" class="form-control" name="roomname" required maxlength="32" pattern="[a-zA-Z0-9_-]+" placeholder="Ex: room123">
            </div>
            <div class="mb-3">
                <label class="form-label">Encryption key</label>
                <input type="password" class="form-control" name="key" required maxlength="32" placeholder="Enter the room key">
            </div>
            <button type="submit" class="btn mhcn-btn w-100">Join</button>
            <button type="button" class="btn btn-link w-100 mt-2" id="back-btn">Back</button>
        </form>
    `);
    document.getElementById("back-btn").onclick = showHome;
    document.getElementById("join-room-form").onsubmit = async (e) => {
        e.preventDefault();
        const roomname = e.target.roomname.value.trim();
        const key = e.target.key.value;
        // Try to join the room
        const resp = await fetch(API_URL, {
            method: "POST",
            headers: {"Content-Type": "application/x-www-form-urlencoded"},
            body: new URLSearchParams({
                action: "get_room",
                roomname
            })
        });
        const text = await resp.text();
        console.log('Backend response:', text);
        let data;
        try {
            data = JSON.parse(text);
        } catch (e) {
            alert('Error processing server response: ' + text);
            return;
        }
        if (data.success) {
            // Test key
            const decrypted = await decryptJSON(data.cipher, key);
            console.log("Trying to decrypt with key:", key);
            if (decrypted) {
                addChatroomToLocal(roomname, key);
                showEnterRoom(roomname, key);
            } else {
                alert("Incorrect encryption key.");
            }
        } else {
            alert(data.error || "Chatroom not found.");
        }
    };
}

let chatroomInterval = null;
let currentRoom = null;
let currentKey = null;
let lastMessagesHash = null;

function showEnterRoom(roomname, key) {
    currentRoom = roomname;
    currentKey = key;
    show(`
        <div class="mb-3 d-flex align-items-center">
            <button class="btn btn-link text-light p-0 me-2" id="back-btn"><i class="bi bi-arrow-left"></i></button>
            <h5 class="mb-0 me-auto">${roomname}</h5>
            <button class="btn btn-link text-danger p-0 ms-2" id="leave-btn" title="Leave room"><i class="bi bi-x-lg"></i></button>
        </div>
        <div id="chat-messages" class="chat-messages mhcn-scrollbar mb-3"></div>
        <form id="send-message-form" autocomplete="off" class="d-flex flex-column gap-2">
            <div class="input-group">
                <input type="text" class="form-control" name="message" placeholder="Type your message..." maxlength="500" autocomplete="off">
                <button class="btn mhcn-btn" type="submit"><i class="bi bi-send"></i></button>
            </div>
            <div class="input-group">
                <input type="file" class="form-control" name="svgfile" accept=".svg,image/svg+xml">
                <button class="btn btn-outline-light" type="button" id="send-svg-btn"><i class="bi bi-image"></i> Send SVG</button>
            </div>
        </form>
    `);
    document.getElementById("back-btn").onclick = () => {
        clearInterval(chatroomInterval);
        showHome();
    };
    document.getElementById("leave-btn").onclick = () => {
        clearInterval(chatroomInterval);
        // Remove from local list
        let rooms = getChatrooms().filter(r => r.name !== roomname);
        saveChatrooms(rooms);
        showHome();
    };
    document.getElementById("send-message-form").onsubmit = async (e) => {
        e.preventDefault();
        const msg = e.target.message.value.trim();
        if (!msg) return;
        await sendMessage(roomname, key, {type: "text", text: msg});
        e.target.message.value = "";
    };
    document.getElementById("send-svg-btn").onclick = async () => {
        const fileInput = document.querySelector('input[name="svgfile"]');
        if (fileInput.files.length === 0) return alert("Select an SVG file.");
        const file = fileInput.files[0];
        if (file.type !== "image/svg+xml" && !file.name.endsWith(".svg")) {
            alert("Only SVG files are allowed.");
            return;
        }
        const reader = new FileReader();
        reader.onload = async function(e) {
            let svgText = e.target.result;
            // Sanitize SVG (remove scripts)
            svgText = svgText.replace(/<script[\s\S]*?>[\s\S]*?<\/script>/gi, "");
            await sendMessage(roomname, key, {type: "svg", svg: svgText});
            fileInput.value = "";
        };
        reader.readAsText(file);
    };
    // Load and update messages
    loadAndRenderMessages(roomname, key);
    chatroomInterval = setInterval(() => {
        loadAndRenderMessages(roomname, key, true);
    }, 2000);
}

async function sendMessage(roomname, key, content) {
    const account = getAccount();
    try {
        const resp = await fetch(API_URL, {
            method: "POST",
            headers: {"Content-Type": "application/x-www-form-urlencoded"},
            body: new URLSearchParams({
                action: "send_message",
                roomname,
                key,
                message: JSON.stringify({
                    author: account.username,
                    datetime: new Date().toISOString(),
                    ...content
                })
            })
        });
        const text = await resp.text();
        console.log('Backend response:', text);
        let data;
        try {
            data = JSON.parse(text);
        } catch (e) {
            alert('Error processing server response: ' + text);
            return;
        }
        if (!data.success) {
            alert(data.error || "Error sending message.");
        }
    } catch (e) {
        console.error('Network error:', e);
        alert('Connection error with server.');
    }
}

async function loadAndRenderMessages(roomname, key, onlyIfChanged = false) {
    try {
        const resp = await fetch(API_URL, {
            method: "POST",
            headers: {"Content-Type": "application/x-www-form-urlencoded"},
            body: new URLSearchParams({
                action: "get_room",
                roomname
            })
        });
        const text = await resp.text();
        console.log('Backend response:', text);
        let data;
        try {
            data = JSON.parse(text);
        } catch (e) {
            console.error('Invalid JSON response:', text);
            document.getElementById("chat-messages").innerHTML = `<div class="text-danger">Error processing server response.</div>`;
            return;
        }
        if (!data.success) {
            document.getElementById("chat-messages").innerHTML = `<div class="text-danger">Error loading messages.</div>`;
            return;
        }
        const decrypted = await decryptJSON(data.cipher, key);
        if (!decrypted) {
            document.getElementById("chat-messages").innerHTML = `<div class="text-danger">Incorrect encryption key.</div>`;
            return;
        }
        // Check if changed
        const hash = JSON.stringify(decrypted);
        if (onlyIfChanged && hash === lastMessagesHash) return;
        lastMessagesHash = hash;
        renderMessages(decrypted);
    } catch (e) {
        console.error('Network error:', e);
        document.getElementById("chat-messages").innerHTML = `<div class="text-danger">Connection error with server.</div>`;
    }
}

function renderMessages(messages) {
    const account = getAccount();
    let html = messages.map(msg => {
        let author = `<span class="author">${msg.author}</span>`;
        let time = `<span class="timestamp ms-2">${formatDate(msg.datetime)}</span>`;
        let content = "";
        if (msg.type === "text") {
            content = `<div class="text">${escapeHTML(msg.text)}</div>`;
        } else if (msg.type === "svg") {
            content = `<div class="text"><img src="data:image/svg+xml;base64,${btoa(msg.svg)}" alt="SVG"></div>`;
        }
        return `<div class="chat-message">${author} ${time}${content}</div>`;
    }).join('');
    document.getElementById("chat-messages").innerHTML = html;
    // Scroll to bottom
    const el = document.getElementById("chat-messages");
    el.scrollTop = el.scrollHeight;
}

function formatDate(dt) {
    const d = new Date(dt);
    return d.toLocaleString("en-US", {dateStyle: "short", timeStyle: "short"});
}

function escapeHTML(str) {
    return str.replace(/[&<>"']/g, function(m) {
        return ({
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#39;'
        })[m];
    });
}

// ========== INITIALIZATION ==========
showHome();
</script>

<!-- Bootstrap Icons -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
